# BeUnadressedHealthMessageExchangePlatform - Digital Referral Prescription Implementation Guide v1.0.0

## NamingSystem: BeUnadressedHealthMessageExchangePlatform 

 
UHMEP naming system 

### Summary

| | |
| :--- | :--- |
| Defining URL | https://www.ehealth.fgov.be/standards/fhir/drp/NamingSystem/be-ns-uhmep |
| Version | 1.0.0 |
| Name | BeUnadressedHealthMessageExchangePlatform |
| Status | active |
| Definition | UHMEP naming system |

### Identifiers

* **Type**: URI
  * **Value**: https://www.ehealth.fgov.be/standards/fhir/referral/NamingSystem/uhmep
  * **Preferred**: true



## Resource Content

```json
{
  "resourceType" : "NamingSystem",
  "id" : "be-ns-uhmep",
  "extension" : [
    {
      "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-NamingSystem.url",
      "valueUri" : "https://www.ehealth.fgov.be/standards/fhir/drp/NamingSystem/be-ns-uhmep"
    },
    {
      "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-NamingSystem.version",
      "valueString" : "1.0.0"
    }
  ],
  "name" : "BeUnadressedHealthMessageExchangePlatform",
  "status" : "active",
  "kind" : "identifier",
  "date" : "2020-06-01",
  "contact" : [
    {
      "name" : "HL7 Belgium",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://hl7belgium.org"
        }
      ]
    },
    {
      "name" : "Message-Structure",
      "telecom" : [
        {
          "system" : "email",
          "value" : "message-structure@ehealth.fgov.be",
          "use" : "work"
        }
      ]
    }
  ],
  "description" : "UHMEP naming system",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "BE",
          "display" : "Belgium"
        }
      ]
    }
  ],
  "uniqueId" : [
    {
      "type" : "uri",
      "value" : "https://www.ehealth.fgov.be/standards/fhir/referral/NamingSystem/uhmep",
      "preferred" : true
    }
  ]
}

```
