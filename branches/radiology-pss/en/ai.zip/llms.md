# hl7.fhir.be.drp#1.0.0: Digital Referral Prescription Implementation Guide(en)

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)
* [Changes](changes.md)
* [Guidance](guidance.md)
* [Downloads](downloads.md)

## Resources

### CodeSystems

* [BeCSAnnex81StatusReason](CodeSystem-be-cs-annex81-status-reason.md)
* [BeCSImagingModality](CodeSystem-be-cs-imaging-modality.md)
* [BeCSImagingPriority](CodeSystem-be-cs-imaging-priority.md)
* [BeCSImplantType](CodeSystem-be-cs-implant-type.md)
* [BeCSRequestTrack](CodeSystem-be-cs-request-track.md)
* [BeTempRequestedServiceDetail](CodeSystem-be-cs-temp-requested-service-detail.md)
* [BeTempRequestedService](CodeSystem-be-cs-temp-requested-service.md)
* [BePrescriptionStatusReason](CodeSystem-be-prescription-status-reason.md)
* [BeTreatmentStatusReason](CodeSystem-be-treatment-status-reason.md)
* [Precoordinated Radiology Exam Code System (Demo)](CodeSystem-precoordinated-radiology.md)

### ValueSets

* [BeVSAnnex81ReasonCode](ValueSet-be-vs-annex-81-reason-code.md)
* [BeVSAnnex81StatusReason](ValueSet-be-vs-annex81-status-reason.md)
* [Body Site](ValueSet-be-vs-bodysite-nursing.md)
* [BeVSImagingModality](ValueSet-be-vs-imaging-modality.md)
* [BeVSImagingPriority](ValueSet-be-vs-imaging-priority.md)
* [BeVSImplantType](ValueSet-be-vs-implant-type.md)
* [BeVSPerformerTaskStatusReason](ValueSet-be-vs-performer-task-status-reason.md)
* [BeVSPrescriptionStatusReason](ValueSet-be-vs-prescription-status-reason.md)
* [BeReferralCategory](ValueSet-be-vs-referral-category.md)
* [BeVSRequestIntent](ValueSet-be-vs-request-intent.md)
* [BeVSRequestNoteType](ValueSet-be-vs-request-note-type.md)
* [BeVSRequestTrack](ValueSet-be-vs-request-track.md)
* [BeVSRequestedServicesNurseDetail](ValueSet-be-vs-requested-services-nurse-detail.md)
* [BeVSRequestedServicesNurse](ValueSet-be-vs-requested-services-nurse.md)
* [BeVSTaskIntent](ValueSet-be-vs-task-intent.md)
* [BeVSTreatmentStatusReason](ValueSet-be-vs-treatment-status-reason.md)

### Logicals

* [BeModelAnnex81](StructureDefinition-BeModelAnnex81.md)
* [BeModelAssignment](StructureDefinition-BeModelAssignment.md)
* [BeModelNursingPrescription](StructureDefinition-BeModelNursingPrescription.md)
* [BeModelOrganisationClaim](StructureDefinition-BeModelOrganisationClaim.md)
* [BeModelRadiologyPrescription](StructureDefinition-BeModelRadiologyPrescription.md)
* [BeModelReferralPrescription](StructureDefinition-BeModelReferralPrescription.md)
* [BeModelTreatmentStatus](StructureDefinition-BeModelTreatmentStatus.md)

### Resource Profiles

* [BeAnnex81](StructureDefinition-be-annex-81.md)
* [BeImagingAttentionConditionsResponse](StructureDefinition-be-imaging-attention-conditions-response.md)
* [BeAssignmentTask](StructureDefinition-be-organization-task.md)
* [BePerformerTask](StructureDefinition-be-performer-task.md)
* [BeReferralServiceRequestDiagnosticImaging](StructureDefinition-be-referral-servicerequest-diagnosticimaging.md)
* [BeReferralServiceRequestNursing](StructureDefinition-be-referral-servicerequest-nursing.md)
* [BeReferralServiceRequest](StructureDefinition-be-referral-servicerequest.md)
* [BeReferralTask](StructureDefinition-be-referral-task.md)

### Extensions

* [BeFeedbackToPrescriber](StructureDefinition-be-ext-feedback-to-prescriber.md)
* [BeLatestEndDate](StructureDefinition-be-ext-latest-end-date.md)
* [BePerformerType](StructureDefinition-be-ext-performer-type.md)
* [BePSSInfo](StructureDefinition-be-ext-pss-info.md)
* [BeRecordedDate](StructureDefinition-be-ext-recorded-date.md)
* [BeRelevantInfo](StructureDefinition-be-ext-relevant-info.md)
* [BeRequestDevice](StructureDefinition-be-ext-request-device.md)
* [BeRequestPriorityReason](StructureDefinition-be-ext-request-priority-reason.md)
* [BeUrgencyJustification](StructureDefinition-be-ext-urgency-justification.md)
* [BeValidityPeriod](StructureDefinition-be-ext-validity-period.md)

### ImplementationGuides

* [Digital Referral Prescription Implementation Guide](ImplementationGuide-hl7.fhir.be.drp.md)

### NamingSystems

* [BeNsUhmepShort](NamingSystem-be-ns-uhmep-short.md)
* [BeUnadressedHealthMessageExchangePlatform](NamingSystem-be-ns-uhmep.md)

### Parameters

* [terminology-expansion](Parameters-terminology-expansion.md)

### Questionnaires

* [Imaging Attention Conditions Questionnaire](Questionnaire-be-questionnaire-imaging-attention-conditions.md)

### SearchParameters

* [statusReason](SearchParameter-be-sp-serviceRequest-statusReason.md)

### Tasks

* [example01-care02-colon-cleansing-performer-task](Task-example01-care02-colon-cleansing-performer-task.md)
* [example01-care02-colon-cleansing-referral-task](Task-example01-care02-colon-cleansing-referral-task.md)
* [performer-task-1-uc5a-1](Task-performer-task-1-uc5a-1.md)
* [referral-task-uc5a-1](Task-referral-task-uc5a-1.md)
* [referral-task](Task-referral-task.md)
* [ucgh222p12-1-2-1](Task-ucgh222p12-1-2-1.md)
* [ucgh222p12-1-2](Task-ucgh222p12-1-2.md)
* [ucgh222p12-2-2-1](Task-ucgh222p12-2-2-1.md)
* [ucgh222p12-2-2-2](Task-ucgh222p12-2-2-2.md)
* [ucgh222p12-2-2](Task-ucgh222p12-2-2.md)

### Examples

* [Requester1 (Practitioner)](Practitioner-Requester1.md)
* [practitioner2 (Practitioner)](Practitioner-practitioner2.md)
* [DOCTOR-10829059004 (PractitionerRole)](PractitionerRole-DOCTOR-10829059004.md)
* [DOCTOR-12009390800 (PractitionerRole)](PractitionerRole-DOCTOR-12009390800.md)
* [NURSE-45094508408 (PractitionerRole)](PractitionerRole-NURSE-45094508408.md)
* [example01-care02-colon-cleansing (ServiceRequest)](ServiceRequest-example01-care02-colon-cleansing.md)
* [example02-referralprescription-nursing-digestive-system-care (ServiceRequest)](ServiceRequest-example02-referralprescription-nursing-digestive-system-care.md)
* [example03-referralprescription-nursing-compressiontherapy (ServiceRequest)](ServiceRequest-example03-referralprescription-nursing-compressiontherapy.md)
* [example04-referralprescription-nursing-bladder-care (ServiceRequest)](ServiceRequest-example04-referralprescription-nursing-bladder-care.md)
* [example05-referralprescription-nursing-digestive-system-care (ServiceRequest)](ServiceRequest-example05-referralprescription-nursing-digestive-system-care.md)
* [example06-referralprescription-nursing-compression-therapy (ServiceRequest)](ServiceRequest-example06-referralprescription-nursing-compression-therapy.md)
* [example09-referralprescription-nursing-woundcare (ServiceRequest)](ServiceRequest-example09-referralprescription-nursing-woundcare.md)
* [example12-referralprescription-nursing-annex81 (ServiceRequest)](ServiceRequest-example12-referralprescription-nursing-annex81.md)
* [example16-referralprescription-nursing-bladder-care (ServiceRequest)](ServiceRequest-example16-referralprescription-nursing-bladder-care.md)
* [example24-referralprescription-nursing-non-reimbursable (ServiceRequest)](ServiceRequest-example24-referralprescription-nursing-non-reimbursable.md)
* [example26-referralprescription-nursing-other (ServiceRequest)](ServiceRequest-example26-referralprescription-nursing-other.md)
* [example32-referralprescription-nursing-chronical-psychiatric (ServiceRequest)](ServiceRequest-example32-referralprescription-nursing-chronical-psychiatric.md)
* [referralprescription-nursing-example2-digestive-system-care (ServiceRequest)](ServiceRequest-referralprescription-nursing-example2-digestive-system-care.md)
* [referralprescription-nursing-example3-compression-therapy (ServiceRequest)](ServiceRequest-referralprescription-nursing-example3-compression-therapy.md)
* [referralprescription-nursing-example5-digestive-system-care (ServiceRequest)](ServiceRequest-referralprescription-nursing-example5-digestive-system-care.md)
* [referralprescription-nursing-example6-compression-therapy (ServiceRequest)](ServiceRequest-referralprescription-nursing-example6-compression-therapy.md)
* [uc5a-1 (ServiceRequest)](ServiceRequest-uc5a-1.md)
* [ucgh222p12-1 (ServiceRequest)](ServiceRequest-ucgh222p12-1.md)
* [ucgh222p12-2 (ServiceRequest)](ServiceRequest-ucgh222p12-2.md)
* [ucgh222p12-3 (ServiceRequest)](ServiceRequest-ucgh222p12-3.md)
* [ucgh241p110-1 (ServiceRequest)](ServiceRequest-ucgh241p110-1.md)
* [ucgh241p111-1 (ServiceRequest)](ServiceRequest-ucgh241p111-1.md)
* [ucgh241p15-1 (ServiceRequest)](ServiceRequest-ucgh241p15-1.md)
* [ucgh241p16-1 (ServiceRequest)](ServiceRequest-ucgh241p16-1.md)
* [ucgh241p17-1 (ServiceRequest)](ServiceRequest-ucgh241p17-1.md)
* [ucgh241p18-1 (ServiceRequest)](ServiceRequest-ucgh241p18-1.md)
* [ucgh241p19-1 (ServiceRequest)](ServiceRequest-ucgh241p19-1.md)
