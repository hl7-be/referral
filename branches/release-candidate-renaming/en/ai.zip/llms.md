# hl7.fhir.be.referral#1.0.0: Referral Prescription Implementation Guide(en)

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)
* [Changes](changes.md)
* [Guidance](guidance.md)
* [Downloads](downloads.md)

## Resources

### CodeSystems

* [eReferral Annex 81 Status Reason](CodeSystem-be-cs-annex81-status-reason.md)
* [eReferral Diabetic Education Type](CodeSystem-be-cs-diabetic-education-type.md)
* [eReferral Generic Care Types](CodeSystem-be-cs-generic-care-types.md)
* [eReferral Glycemia Measurement Timing](CodeSystem-be-cs-glycemia-measurement-timing.md)
* [eReferral Imaging Modality](CodeSystem-be-cs-imaging-modality.md)
* [eReferral Imaging Priority](CodeSystem-be-cs-imaging-priority.md)
* [eReferral Note Types](CodeSystem-be-cs-note-types.md)
* [eReferral Prescription Type](CodeSystem-be-cs-prescription-type.md)
* [PSS Indication CodeSystem](CodeSystem-be-cs-pss-indication.md)
* [eReferral Radiology SupportingInfo Role CodeSystem](CodeSystem-be-cs-radiology-supporting-info-role.md)
* [eReferral Request Track](CodeSystem-be-cs-request-track.md)
* [eReferral Session Types](CodeSystem-be-cs-session-types.md)
* [BePrescriptionStatusReason](CodeSystem-be-prescription-status-reason.md)
* [BeTreatmentStatusReason](CodeSystem-be-treatment-status-reason.md)

### ValueSets

* [eReferral Annex 81 Care Requested](ValueSet-be-vs-annex81-care-requested.md)
* [eReferral Annex 81 Medical Problem](ValueSet-be-vs-annex81-medical-problem.md)
* [eReferral Annex 81 Nursing Diagnosis](ValueSet-be-vs-annex81-nursing-diagnosis.md)
* [BeVSAnnex81StatusReason](ValueSet-be-vs-annex81-status-reason.md)
* [eReferral Annex 81 Technical Type](ValueSet-be-vs-annex81-technical-type.md)
* [eReferral Body Site](ValueSet-be-vs-body-site.md)
* [eReferral Body Topography](ValueSet-be-vs-body-topography.md)
* [eReferral Categories of Care](ValueSet-be-vs-categories-of-care.md)
* [eReferral Diabetes Education Identifier](ValueSet-be-vs-diabetes-education-identifier.md)
* [eReferral/PSS Diagnostic Imaging Indication](ValueSet-be-vs-diagnostic-imaging-indication.md)
* [eReferral/PSS Diagnostic Imaging Procedure](ValueSet-be-vs-diagnostic-imaging-procedure.md)
* [eReferral Education Type With Trajectory](ValueSet-be-vs-education-type-with-trajectory.md)
* [eReferral Education Type Without Trajectory](ValueSet-be-vs-education-type-without-trajectory.md)
* [eReferral Educator Type](ValueSet-be-vs-educator-type.md)
* [eReferral Glycemia Measurement Time](ValueSet-be-vs-glycemia-measurement-time.md)
* [eReferral Imaging Modality ValueSet](ValueSet-be-vs-imaging-modality.md)
* [eReferral Imaging Priority ValueSet](ValueSet-be-vs-imaging-priority.md)
* [eReferral Implant Type](ValueSet-be-vs-implant-type.md)
* [eReferral Note Type](ValueSet-be-vs-note-type.md)
* [eReferral Nursing Care Requested](ValueSet-be-vs-nursing-care-requested.md)
* [eReferral Nursing Prescription Technical Type](ValueSet-be-vs-nursing-prescription-technical-type.md)
* [eReferral Parameter Type](ValueSet-be-vs-parameter-type.md)
* [BeVSPrescriptionStatusReason](ValueSet-be-vs-prescription-status-reason.md)
* [eReferral Prescription Type ValueSet](ValueSet-be-vs-prescription-type.md)
* [PSS Indication](ValueSet-be-vs-pss-indication.md)
* [eReferral Radiology SupportingInfo Role ValueSet](ValueSet-be-vs-radiology-supporting-info-role.md)
* [BeVSRequestIntent](ValueSet-be-vs-request-intent.md)
* [eReferral request track](ValueSet-be-vs-request-track.md)
* [eReferral Sample Substance Type](ValueSet-be-vs-sample-substance-type.md)
* [eReferral Session Type Extended](ValueSet-be-vs-session-type-extended.md)
* [eReferral Session Type](ValueSet-be-vs-session-type.md)
* [BeVSTaskIntent](ValueSet-be-vs-task-intent.md)
* [BeVSTreatmentStatusReason](ValueSet-be-vs-treatment-status-reason.md)

### Logicals

* [BeModelAnnex81](StructureDefinition-BeModelAnnex81.md)
* [BeModelAssignment](StructureDefinition-BeModelAssignment.md)
* [BeModelNursingPrescription](StructureDefinition-BeModelNursingPrescription.md)
* [BeModelOrganisationClaim](StructureDefinition-BeModelOrganisationClaim.md)
* [BeModelReferralPrescription](StructureDefinition-BeModelReferralPrescription.md)
* [BeModelTreatmentStatus](StructureDefinition-BeModelTreatmentStatus.md)

### Resource Profiles

* [BeAnnex81](StructureDefinition-be-annex-81.md)
* [BeImagingAttentionConditionsResponse](StructureDefinition-be-imaging-attention-conditions-response.md)
* [BeOrganizationTask](StructureDefinition-be-organization-task.md)
* [BePerformerTask](StructureDefinition-be-performer-task.md)
* [BeServiceRequestDiagnosticImaging](StructureDefinition-be-referral-servicerequest-diagnosticimaging.md)
* [BeReferralServiceRequestNursing](StructureDefinition-be-referral-servicerequest-nursing.md)
* [BeReferralServiceRequest](StructureDefinition-be-referral-servicerequest.md)
* [BeReferralTask](StructureDefinition-be-referral-task.md)

### Extensions

* [CodeableConcept Extension for Reference](StructureDefinition-be-ext-codeable-concept.md)
* [BeFeedbackToPrescriber](StructureDefinition-be-ext-feedback-to-prescriber.md)
* [BeLatestEndDate](StructureDefinition-be-ext-latest-end-date.md)
* [BePerformerType](StructureDefinition-be-ext-performer-type.md)
* [BePSSInfo](StructureDefinition-be-ext-pss-info.md)
* [eReferral Radiology SupportingInfo Role](StructureDefinition-be-ext-radiology-supporting-info-role.md)
* [BeRelevantInfo](StructureDefinition-be-ext-relevant-info.md)
* [eReferral String Date](StructureDefinition-be-ext-string-date.md)
* [BeUrgencyJustification](StructureDefinition-be-ext-urgency-justification.md)
* [BeValidityPeriod](StructureDefinition-be-ext-validity-period.md)

### GraphDefinitions

* [FullReferralPrescription](GraphDefinition-full-referral-prescription.md)

### ImplementationGuides

* [Referral Prescription Implementation Guide](ImplementationGuide-hl7.fhir.be.referral.md)

### NamingSystems

* [BePSSId](NamingSystem-be-ns-pss-id.md)
* [BeNsUhmepShort](NamingSystem-be-ns-uhmep-short.md)
* [BeUnadressedHealthMessageExchangePlatform](NamingSystem-be-ns-uhmep.md)

### OperationDefinitions

* [BeOpApproveAnnex81](OperationDefinition-be-op-approve-annex81.md)
* [BeOpRejectAnnex81](OperationDefinition-be-op-reject-annex81.md)

### Parameters

* [terminology-expansion](Parameters-terminology-expansion.md)

### Questionnaires

* [Imaging Attention Conditions Questionnaire](Questionnaire-be-questionnaire-imaging-attention-conditions.md)

### Examples

* [example-referral-servicerequest (ServiceRequest)](ServiceRequest-example-referral-servicerequest.md)
* [example-referral-task (Task)](Task-example-referral-task.md)
